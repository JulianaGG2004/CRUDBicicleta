package com.reto2.reto2.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reto2.reto2.model.entity.Evento;

public interface IEventoDao extends JpaRepository<Evento,Long>{

}
