package com.reto2.reto2.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reto2.reto2.model.entity.Competencia;

public interface ICompetenciaDao extends JpaRepository<Competencia,Long>{

	
}
